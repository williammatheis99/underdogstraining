
const menuButton = document.querySelector(".menu-toggle");
const navigation = document.querySelector("nav");

menuButton.addEventListener("click", function() {
    navigation.classList.toggle("open");
});

const navigationLinks = document.querySelectorAll("nav a");

navigationLinks.forEach(function(link) {
    link.addEventListener("click", function() {
        navigation.classList.remove("open");
    });
});

